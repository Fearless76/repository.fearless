# -*- coding: utf-8 -*-

'''
    Cerebro ShowBox Scraper

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import dom_parser2
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['rlsscn.in']
        self.base_link = 'http://rlsscn.in/'
        self.search_link = '/?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = (urllib.quote_plus(title) + '+' + year)
            url2 = urlparse.urljoin(self.base_link, self.search_link % query)
            url = {'imdb': imdb, 'title': title, 'year': year, 'url': url2, 'content': 'movie'}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
             
            tvshowtitle = data['tvshowtitle']
            year = data['year']  
            
            query = '%s season %d' % (tvshowtitle, int(season))
            url2 = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(query))
            r = client.request(url2)
            if 'We apologize for any inconvenience,' in r:
            
                query = '%s+season+%d+episode+%d' % (urllib.quote_plus(cleantitle.geturl(tvshowtitle)).replace('-','+'), int(season), int(episode))
                url2 = urlparse.urljoin(self.base_link, self.search_link2 % query)

                r = client.request(url2, headers=myheaders)
                if 'We apologize for any inconvenience,' in r:
                    query = '%s+%s' % (cleantitle.geturl(tvshowtitle).replace('-','+'), premiered.replace('-','+'))
                    url2 = urlparse.urljoin(self.base_link, self.search_link2 % query)
                
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url = {'imdb': imdb, 'title': title, 'year': year, 'url': url2, 'content': 'episdoe', 'tvshowtitle': tvshowtitle, 'season': season, 'episode': episode, 'premiered': premiered}            
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
            
        sources = []

        try:
            if url == None: return sources

            if debrid.status() == False: raise Exception()

            hostDict = hostprDict + hostDict

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
             
            ref_url = url = data['url']
            
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            hdlr2 = 'season-%01d-episode-%01d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else ''
            imdb = data['imdb']

            content = 'episode' if 'tvshowtitle' in data else 'movie'
            season = data['season'] if 'season' in data else '0'
            episode = data['episode'] if 'episode' in data else '0'
            premiered = data['premiered'] if 'premiered' in data else '0'
                      
            r = client.request(url)
            posts = dom_parser2.parse_dom(r, 'article', {'class': ['post','excerpt']})
            posts = [(dom_parser2.parse_dom(i, 'a', req=['href','title']), i.content) for i in posts if imdb in i.content]
            posts = [(i[0][0].attrs['title'], i[0][0].attrs['href'], i[1]) for i in posts]
            items = []

            for item in posts:
                data = []
                try:
                    name = item[0]
                    name = client.replaceHTMLCodes(name)
                        
                    if content == 'episode':
                        if not hdlr2.lower() in item[1].lower():
                            if not premiered.replace('-','').replace('+','') in item[1].lower().replace('-','').replace('+',''): raise Exception()

                    url = item[1]
                    if 'episode' in url:
                        r = client.request(url)
                        data = client.parseDOM(r, 'div', attrs={'id':'content'})
                        data = re.findall('')
                        print data
                    else:
                        r = client.request(url)
                        data += client.parseDOM(r, 'div', attrs={'id': 'content'})
                        data += client.parseDOM(r, 'div', attrs={'id': 'comments'})
                        urls = dom_parser2.parse_dom(data, 'a', req='href')
                        urls = [i.attrs['href'] for i in urls]

                    for url in urls:
                        try:
                            if any(x in url for x in ['.rar', '.zip', '.iso']): raise Exception()
                            url = client.replaceHTMLCodes(url)
                            url = url.encode('utf-8')

                            host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                            if not host in hostDict: raise Exception()
                            host = client.replaceHTMLCodes(host)
                            host = host.encode('utf-8')

                            quality, info = source_utils.get_release_quality(url, url)

                            try:
                                size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+) (?:GB|GiB|MB|MiB))', item[2])[-1]
                                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                                size = float(re.sub('[^0-9|/.|/,]', '', size))/div
                                size = '%.2f GB' % size
                                info.append(size)
                            except:
                                pass

                            info = ' | '.join(info)
                            
                            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True})
                        except: pass
                except: pass
                
            return sources
        
        except: 
             return sources
             
    def resolve(self, url):
        return url
