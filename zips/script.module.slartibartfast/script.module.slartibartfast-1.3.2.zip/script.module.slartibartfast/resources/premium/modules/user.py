import base64 as b

id   = b.b64decode('c2NyaXB0Lm1vZHVsZS5zdHJlYW1odWI=')

name = b.b64decode('W0NPTE9SIGZmZmYwMDAwXVN0cmVhbUh1YiBQcmVtaXVtWy9DT0xPUl0=')

host = b.b64decode('aHR0cDovL3N0cmVhbWh1YnByZW1pdW0uZGRucy5uZXQ=')

port = b.b64decode('NDU0NQ==')